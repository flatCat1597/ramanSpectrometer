#include "stdio.h"
#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"
extern unsigned char p1[];  // the mbed logo graphic
DigitalOut LCD_LED(D7);

SPI_TFT_ILI9341 TFT(D11, D12, D13, D8, D9, D10,"TFT"); // mosi, miso, sclk, cs, reset, dc

int main()
{
    int i;
    LCD_LED = 1;

    TFT.claim(stdout);
    while(1) {
        TFT.set_orientation(1);
        TFT.background(Black);
        TFT.foreground(White);
        TFT.cls();

        TFT.set_orientation(0);
        TFT.background(Black);
        TFT.cls();

        TFT.set_orientation(1);
        TFT.rect(0,0,320,240,Blue);
        TFT.set_font((unsigned char*) Neu42x35);
        TFT.locate(20,70);
        TFT.printf("meridian");
        TFT.locate(110,100);
        TFT.printf("Scientific");
        TFT.set_font((unsigned char*) Arial24x23);
        TFT.locate(30,140);
        TFT.printf("ramanSpectrometer");
        TFT.set_font((unsigned char*) Arial12x12);
        TFT.locate(160,165);
        printf("version0.1a (2014)");
        double s;

        for (i=0; i<320; i++) {
            s =40 * sin((long double) i / 10 );
            TFT.pixel(i,180 + (int)s-(i-s) ,Green);
        }
        TFT.rect(0,0,320,240,Blue);
        wait(5);

        TFT.foreground(White);
        TFT.background(Blue);
        TFT.cls();
        TFT.set_font((unsigned char*) Arial24x23);
        TFT.locate(0,0);
        TFT.printf("meridianScientific");
        TFT.locate(0,20);
        TFT.printf("ramanSpectrometer");
        TFT.foreground(Green);
        TFT.set_font((unsigned char*) Arial12x12);
        TFT.locate(0,50);
        printf("> version0.1a (2014)");
        TFT.locate(0,65);
        printf("> system initialization...");


    wait(5);
    }
}
